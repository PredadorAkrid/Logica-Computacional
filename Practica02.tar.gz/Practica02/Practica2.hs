module Practica2 where
import LProp

-- Alias de tipos: Sólo sirve para referirnos
-- a un tipo existente por un nuevo nombre, 
-- pero podemos seguir manipulándolo como
-- al tipo subyacente.
type Interpretacion = [(Char, Bool)] -- El tipo Interpretacion representa
                                     -- una asignación de variables proposicionales.




-- Por ejemplo, [('A', True), ('B', False)]
-- asigna la variable A a verdadero y B a falso.


-- interpretaciones toma una lista de nombres de variables
-- proposicionales y regresa una lista de todas las posibles
-- interpretaciones para esas variables.
-- Nótese que si la lista de entrada es de longitud n,
-- la lista de salida tendrá longitud 2^n.
interpretaciones :: [Char] -> [Interpretacion]
interpretaciones [] = [[]]
interpretaciones (c:cs)  = let ints = interpretaciones cs in
                               [(c, True):xs | xs <- ints] ++
                               [(c, False):xs | xs <- ints]
                              -- ^ listas por comprensión.


-- busca toma una proposición (idealmente, una variable)
-- y una interpretación y devuelve su valor de verdad
-- asignado, si es que existe.
busca :: Prop -> Interpretacion -> Bool
busca _ [] = error "No se encontró asignación en la interpretación."
busca pr ((p,b):xs) = if ((PVar p) == pr) then b else busca pr xs -- Ejercicio 1.
--          ^
--          L_ nótese que aquí estamos des-estructurando una tupla al mismo 
--         tiempo que la lista.


-- eval evalúa una fórmula proposicional según una 
-- interpretación dada.
eval :: Prop -> Interpretacion -> Bool
eval PTrue _ = True
eval PFalse _ = False
eval (PVar f)  i = busca (PVar f) i
eval (PNeg f)  i = not (eval f i)
eval (PAnd f g) i = (eval f i) && (eval g i)
eval (POr f g) i = (eval f  i) || eval g  i
eval(PImpl f g) i = (eval (PNeg f) i) || (eval g i)
eval(PEquiv f g) i = (eval (PImpl f g) i) && (eval (PImpl  g f) i) 



-- satisfacible toma una fórmula proposicional
-- y devuelve si es satisfacible, esto es, existe
-- una interpretación con la que se evalúa a True.
-- Este es un problema NP-Completo, pero esto nos 
-- importa muy poco, lo hacemos por fuerza bruta 
-- como se debe.
satisfacible :: Prop -> Bool
satisfacible (PVar p) = True
satisfacible (PNeg p) = not(satisfacible p)
satisfacible (PAnd p q) = satisfacible  p && satisfacible q
satisfacible (POr p  q) = satisfacible p  || satisfacible q
satisfacible (PImpl p q) = satisfacible (PNeg p) || satisfacible q
satisfacible (PEquiv p q) = satisfacible (PImpl p q)  && satisfacible (PImpl q  p)  


-- fnc toma una fórmula proposicional
-- y devuelve una fórmula equivalente a ésta en forma
-- normal conjuntiva. Consúltese el documento Practica2.pdf
-- para conocer el algoritmo.
fnc:: Prop -> Prop
fnc p = disyunciones(meteNegaciones(eliminaImpl(eliminaEquiv p))) -- Ejercicio 

eliminaEquiv :: Prop -> Prop
eliminaEquiv (PVar p)   = (PVar p) 
eliminaEquiv (PNeg p)    = (PNeg (eliminaEquiv p ))  
eliminaEquiv (PAnd p q) =  (PAnd  (eliminaEquiv p) (eliminaEquiv q)) 
eliminaEquiv (POr p q) =    (POr (eliminaEquiv p) (eliminaEquiv q)) 
eliminaEquiv (PImpl p q) = (PImpl (eliminaEquiv p) (eliminaEquiv q)) 
eliminaEquiv (PEquiv p q) = (PAnd (PImpl (eliminaEquiv p) (eliminaEquiv q)) (PImpl (eliminaEquiv q) (eliminaEquiv p))) 

eliminaImpl :: Prop -> Prop

eliminaImpl (PVar p)   = (PVar p) 
eliminaImpl (PNeg p)    = (PNeg (eliminaImpl p)) 
eliminaImpl (PAnd p q) = (PAnd (eliminaImpl p) (eliminaImpl q))
eliminaImpl (POr p q) = (POr (eliminaImpl p) (eliminaImpl q) )
eliminaImpl (PImpl p q) = (POr (PNeg (eliminaImpl p)) (eliminaImpl q))

meteNegaciones :: Prop -> Prop
meteNegaciones (PVar p)   =  (PVar p)
meteNegaciones (PNeg p)    = meteNegacionesAux p --mandamos llamar a la función auxiliar de meteNegaciones
meteNegaciones (PAnd p q) =  (PAnd (meteNegaciones p) (meteNegaciones q)) 
meteNegaciones (POr p q) =  (POr (meteNegaciones p) (meteNegaciones q)) 
 
meteNegacionesAux :: Prop -> Prop
meteNegacionesAux (PVar p)   =  (PNeg (PVar p))
meteNegacionesAux (PNeg (PNeg p)) = meteNegacionesAux p
meteNegacionesAux (PNeg p)    = (meteNegaciones p) 
meteNegacionesAux (POr p q) = (PAnd (meteNegacionesAux p) (meteNegacionesAux q))
meteNegacionesAux (PAnd p q) = (POr (meteNegacionesAux p) (meteNegacionesAux q)) 


disyunciones :: Prop -> Prop 

disyunciones (POr (PAnd r s) q) = disyunciones (PAnd (POr (disyunciones r) (disyunciones q)) (POr (disyunciones s) (disyunciones q)))
disyunciones (POr p (PAnd r s)) = disyunciones (PAnd (POr (disyunciones p) (disyunciones r)) (POr (disyunciones p) (disyunciones s)))
disyunciones (PAnd p q) = (PAnd (disyunciones p) (disyunciones q))
disyunciones p = p



