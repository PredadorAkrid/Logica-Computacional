%Navarrete Puebla Alexis Práctica03

%Ejercicio 1

invierteLista([],[]).
invierteLista([X|XS],RES):- invierteLista(XS,W), append(W,[X],RES).


palindromo(X) :- invierteLista(X,RES), X == RES.


%Ejercicio 2


transition(o,a,b).  
transition(v,b,c).
transition(z,a,a).  
transition(o,c,c).
transition(v,a,c).  
transition(z,c,a).
transition(o,b,b).  
transition(o,c,a).
transition(z,b,a).  
	

process( [] , QINI , QINI).
process([X|XS] , QINI , QF) :- transition(X,QINI,State), process(XS,State, QF).

%Ejercicio 3
 
%Alexis es el protagonista.
%Alexia es la esposa de Alexis.
%Alexandra es la hija de Alexia.
%Alberto es el padre de Alexis.
%Alex es la hija de Alexandra y Alberto.
%Aleksei es el hijo de Alexis y Alexia.


padre(alberto,alexis).
padre(alexandra,alexis).
padre(alexia, alexandra).
padre(alexis,alexandra).
padre(alberto,alex).
padre(alexis,alberto).
padre(alexandra, alex).
padre(alexis,aleksei).
padre(alexia,aleksei).
%suegro(alexis,alberto).
casados(alexis,alexia).
casados(alberto, alexandra).




casados(X,Y) :- casados(Y,X).
hijo(X,Y) :- padre(Y,X).
suegro(X,Y) :- hijo(Z,Y), casados(X,Z).
hermano(X,Y) :- hijo(X,Z), hijo(Y,Z).
abuelo(X,Y) :- hijo(Y,Z), hijo(Z,X).
cuniado(X,Y) :- casados(Z,Y), hermano(Z,X).
tio(X,Y) :- hermano(X,Z), hijo(Y,Z).
bisabuelo(X,Y) :- abuelo(W,Y), padre(X,W).
