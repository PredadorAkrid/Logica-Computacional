% algunos hechos.
alto(diego).
alto(cesar).
alto(vaquero).
% un hecho y una regla de deducción
son_novios(fulana, sutano).
son_novios(X, Y) :- son_novios(Y, X).
% relación que encuentra el último elemento de una lista
my_last([X], X).
my_last([_|XS], Y) :- my_last(XS, Y).
% relación que encuentra la longitud de una lista
len([], 0).
len([_|XS], Y) :- len(XS, L), Y is L + 1.
% relación que encuentra la suma de una lista de números
sum([], 0).
sum([X|XS], Y) :- sum(XS, S), Y is S + X.
% relación que agrega un elemento a un arbol binario de búsqueda.
add(X, empty, tree(X, empty, empty)).
add(X, tree(Y, L, R), tree(Y, L1, R)) :- X =< Y, add(X, L, L1).
add(X, tree(Y, L, R), tree(Y, L, R1)) :- X > Y, add(X, R, R1).
% relación que encuentra el recorrido in order de un arbol binario.
in_order(empty, []).
in_order(tree(X, L, R), Y) :- in_order(L, LL), in_order(R, LR), append(LL, [X|LR], Y). expression if condition;