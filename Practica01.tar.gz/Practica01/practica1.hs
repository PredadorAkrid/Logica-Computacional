--Función remove

(//) :: [a] -> [a] -> [a]
(//) [] y = y
(//) (x:xs) y = x : (xs // y)

remove :: Eq a => a -> [a] -> [a]
remove y [] = []
remove y (x:xs) = if(y == x) 
		  	then remove y xs 
			else [x] // remove y xs

--- Función (\\)

(\\) :: Eq a => [a] -> [a] -> [a]
(\\) [] ys  = []
(\\) (x:xs) ys |  x `elem` ys = (\\)  xs ys
	       | otherwise = x : (\\) xs ys 
			


---Función rmdup

rmdup :: Eq a => [a] -> [a]
rmdup [] = []
rmdup (x:xs) = [x] ++ rmdup(remove x xs)


---Definir un tipo de dato Tree que represente un árbol binario genérico. Que derive la clase show

data Tree a = Empty | Nodo a (Tree a) (Tree a) deriving (Show,Eq)

-- Función insert


---insert :: Ord a => a -> Tree a -> Tree a
---insert x Empty = Nodo x Empty Empty
---insert x (Nodo y izq der)
--			| x >= y =   Nodo y (insert x izq) der
--			| otherwise =  Nodo y izq (insert x der)	
insert :: Ord a => a -> Tree a -> Tree a
insert x Empty = Nodo x Empty Empty
insert x (Nodo y izq der)
			| y == x = Nodo  y izq der
			| y  < x = Nodo y izq (insert x der)
			| y > x = Nodo  y (insert x izq ) der	



-- Función fromList
fromList :: Ord a => [a] -> Tree a
fromList [] = Empty	
fromList (x:xs) = fromList2 (Nodo x Empty Empty) xs   
		where 
			fromList2 (Nodo y izq der) [] = (Nodo y izq der)
			fromList2  (Nodo z izq der) (h:ts)  = fromList2 (insert h (Nodo z izq der)) ts    




--Función inOrder
inOrder :: Tree a -> [a]
inOrder Empty = []
inOrder (Nodo x izq der)  = inOrder izq ++ [x] ++ inOrder der

--Función sort
sort :: Ord a => [a] -> [a]
sort [] = []
sort (x:xs) =  inOrder(fromList (x:xs)) 

		    
		


